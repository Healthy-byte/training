SIEM & correlation: lab data
============================

One folder per lab. The tasks are in "SIEM & Correlation: Student Lab Guide",
which your instructor shares with you.

Folder                       Lab                       Contents
Level1_net_localgroup/       Level 1                   884 Windows events (Sysmon + Security)
Level2B_host_and_network/    Level 2: Lab 2
  host/MKT01_windows_events.json                       53,698 Windows events from one workstation
  zeek/*.log                                           261 Zeek records, one file per log type
Level2A_zeek_apt29_day2/     Level 2: stretch lab      5,664 Zeek records, all log types in one
                             (optional)                file (the log type is in "@stream")
Level3_apt29_day1/           Level 3: APT29 hunt       196,081 Windows events, about 385 MB

Every file has one JSON object per line. Load it into Elastic, Sentinel or
LogRhythm, or query it directly with jq, grep, Python or any tool you like.

Safety
------
These are recordings of real attack tools. Some fields contain encoded
commands, URLs and file hashes. Read and decode them as text. Never run,
download or visit anything you find in the data.

Source
------
OTRF Security-Datasets (Mordor), https://github.com/OTRF/Security-Datasets
  Level 1   datasets/atomic/windows/discovery/host/empire_shell_net_localgroup_administrators.zip
  Lab 2     datasets/compound/LSASS_campaign_01/ (host file renamed; Zeek logs
            converted from Zeek TSV to JSON Lines, field names unchanged)
  Stretch   datasets/compound/apt29/day2/zeek/combined_zeek.log (unchanged)
  Level 3   datasets/compound/apt29/day1/apt29_evals_day1_manual.zip

Check the files with:  sha256sum -c SHA256SUMS
